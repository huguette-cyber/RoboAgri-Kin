#include <stdio.h>
#include <stdlib.h>.
#include <time.h>.

// Etudiant 9 : Capteurs et irrigation - Version 2 Securisee
// RF07 : Decision d'irrigation | RF08 : Securite pompe

int main()
{
    srand(time(NULL));
    int humidite = 20 + rand() % 80; // 20 a 99%
    int niveau = 10 + rand() % 90;   // 10 a 99%
    int seuil = 40;
    int duree_max_pompe = 10; // secondes - RF08

    printf("=== RoboAgri-Kin - Etudiant 9 ===\n");
    printf("Humidite : %d %%\n", humidite);
    printf("Niveau eau : %d %%\n", niveau);
    printf("Seuil : %d %%\n", seuil);

    // CAS 3 : Mesure invalide - Section 5.4
    if (humidite < 0 || humidite > 100 || niveau < 0 || niveau > 100)
    {
        printf("ALERTE : CAPTEUR EN PANNE - Arrosage INTERDIT\n");
        printf("Pompe : OFF - Incident signale\n");
        return 1;
    }

    // CAS 2 : Securite reservoir vide
    if (niveau < 10)
    {
        printf("ALERTE : RESERVOIR VIDE - Pompe BLOQUEE\n");
        printf("Pompe : OFF\n");
        return 0;
    }

    // CAS 1 : Decision
    if (humidite < seuil)
    {
        printf("Sol SEC - Arrosage autorise\n");
        printf("Pompe : ON pendant max %d secondes (Securite RF08)\n", duree_max_pompe);
    }
    else
    {
        printf("Sol HUMIDE - Pas d'arrosage\n");
        printf("Pompe : OFF\n");
    }
    return 0;
}